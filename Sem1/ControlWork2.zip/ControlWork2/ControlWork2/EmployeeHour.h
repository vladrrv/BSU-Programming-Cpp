#pragma once
#include "Worker.h"

class EmployeeHour : public Worker
{
	double hourly_rate;
public:
	EmployeeHour();
	EmployeeHour(const EmployeeHour& o);
	EmployeeHour(unsigned _id, char* _name, double rate = 0);
	double avg_month();
	bool operator > (EmployeeHour& o);
	bool operator < (EmployeeHour& o);
	void operator = (const EmployeeHour& o);
};
