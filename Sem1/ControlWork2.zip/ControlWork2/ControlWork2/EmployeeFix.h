#pragma once
#include "Worker.h"

class EmployeeFix : public Worker
{
	double fix_salary;
public:
	EmployeeFix();
	EmployeeFix(const EmployeeFix& o);
	EmployeeFix(unsigned _id, char* _name, double sal = 0);
	double avg_month();
	bool operator > (EmployeeFix& o);
	bool operator < (EmployeeFix& o);
	void operator = (const EmployeeFix& o);
};
