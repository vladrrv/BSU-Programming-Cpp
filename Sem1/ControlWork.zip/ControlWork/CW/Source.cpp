/* VARIANT 5

	  *		  *	  * * * *
	   *     *	  *
		*	*	  * * *	*
		 * *			*
		  *       * * * * 
*/
#include <iostream>
#include <conio.h>
using namespace std;

class DecNumber
{
	char original[256];
	int wholePart;
	char fracPart[256];
public:
	DecNumber()
	{
		strcpy_s(original, "0.0");
		wholePart = 0;
		strcpy_s(fracPart, "0");
	}
	DecNumber(char *buf)
	{
		strcpy_s(original, buf);
		int b, sign = 1, i = 0;
		char numbuf[256];
		if (buf[0] == '-')
		{
			sign = -1;
			i++;
		}
		for (i; i < strlen(buf); i++)
		{
			b = 0;
			if (buf[i] == '.')
			{
				if (i == 0) wholePart = 0;
				i++;
				while (isdigit(buf[i]))
					numbuf[b++] = buf[i++];
				numbuf[b] = 0;
				if (b > 0)
					strcpy_s(fracPart, numbuf);
				else
					strcpy_s(fracPart, "0");
			}
			else
			{
				while (isdigit(buf[i]))
					numbuf[b++] = buf[i++];
				numbuf[b] = 0;
				if (b > 0)
				{
					wholePart = sign * atoi(numbuf);
					sign = 1;
					i--;
				}
			}
		}
		cout << "Int: " << wholePart << " \t Frac: " << fracPart << endl;
	}
	void printNum()
	{
		cout << original << " ";
	}
	int getWholePartLength()
	{
		int wh = wholePart, l = 0;
		while (wh > 0)
		{
			wh /= 10;
			l++;
		}
		return l;
	}
	int getFracDig(int pos)
	{
		if (pos < strlen(fracPart))
			return fracPart[pos] - 48;
		else
			return 0;
	}
};

void minFracHundrDig(DecNumber *arr, int count)
{
	int minDig = arr[0].getFracDig(1), curDig, index[256], s = 0;
	index[0] = 0;
	//index[1] = -1; // that may be used for returning (to know the actual length of index)
	for (int i = 1; i < count; i++)
	{
		curDig = arr[i].getFracDig(1);
		cout << arr[i].getFracDig(1);
		if (curDig < minDig)
		{
			minDig = curDig;
			index[0] = i;
			//index[1] = -1;
			s = 0;
		}
		else if (curDig == minDig)
		{
			index[++s] = i;
			//index[s + 1] = -1;
		}
	}
	cout << "\nThere is(are) " << s + 1 << " number(s) with smallest digit on 100th position in its(their) fractional part: ";
	for (int i = 0; i <= s; i++)
		arr[index[i]].printNum();
	//return index;
}

void quickSort(int *list, int left, int right, DecNumber *arr)
{
	int pivot = list[(left + right) / 2], left_arrow = left, right_arrow = right;
	do
	{
		while (list[right_arrow] > pivot)
			right_arrow--;
		while (list[left_arrow] < pivot)
			left_arrow++;
		if (left_arrow <= right_arrow)
		{
			swap(list[left_arrow], list[right_arrow]);
			DecNumber t;
			memcpy(&t, &arr[left_arrow], sizeof(DecNumber));
			memcpy(&arr[left_arrow], &arr[right_arrow], sizeof(DecNumber));
			memcpy(&arr[right_arrow], &t, sizeof(DecNumber));
			left_arrow++;
			right_arrow--;
		}
	} while (right_arrow >= left_arrow);
	if (left < right_arrow)
		quickSort(list, left, right_arrow, arr);
	if (left_arrow < right)
		quickSort(list, left_arrow, right, arr);
}
void sortByWholePartLength(DecNumber *arr, int count)
{
	int list[256];
	for (int i = 0; i < count; i++)
		list[i] = arr[i].getWholePartLength();
	quickSort(list, 0, count - 1, arr);
	cout << "\nSorted by length of whole part: ";
	for (int i = 0; i < count; i++)
		arr[i].printNum();
}

void main()
{
	DecNumber *arr = new DecNumber[256];
	int  j = 0, l = 0, k = 0, b = 0;
	char buf[256], numbuf[256];
	size_t g = 256;
	_cgets_s(buf, g, &g);
	for (int i = 0; i < strlen(buf); i++)
	{
		b = 0;
		while (buf[i] != ' ' && buf[i] != 0)
			numbuf[b++] = buf[i++];
		numbuf[b] = 0;
		if (b > 0)
			arr[k++] = DecNumber(numbuf);
	}
	minFracHundrDig(arr, k);
	sortByWholePartLength(arr, k);
	_getch();
}