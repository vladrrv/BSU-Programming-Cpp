#include <iostream>
#include <conio.h>
using namespace std;
// VARIANT 5
class DecNumber
{
public:
	int wholePart;
	char fracPart[256];
	DecNumber()
	{
		wholePart = 0;
		strcpy_s(fracPart, "0");
	}
	DecNumber(char *buf)
	{
		int b, sign = 1, i = 0;
		char numbuf[256];
		if (buf[0] == '-')
		{
			sign = -1;
			i++;
		}
		for (i; i < strlen(buf); i++)
		{
			b = 0;
			if (buf[i] == '.')
			{
				if (i == 0) wholePart = 0;
				i++;
				while (isdigit(buf[i]))
					numbuf[b++] = buf[i++];
				numbuf[b] = 0;
				if (b > 0)
					strcpy_s(fracPart, numbuf);
				else
					strcpy_s(fracPart, "0");
			}
			else
			{
				while (isdigit(buf[i]))
					numbuf[b++] = buf[i++];
				numbuf[b] = 0;
				if (b > 0)
				{
					wholePart = sign * atoi(numbuf);
					sign = 1;
					i--;
				}
			}
		}
		cout << "Int: " << wholePart << "  Frac: " << fracPart << endl;
	}
	int fracDigsCount()
	{
		return strlen(fracPart);
	}
	int fracDigsSum()
	{
		int sum = 0;
		for (int i = 0; i < strlen(fracPart); i++)
			sum += fracPart[i] - 48;
		return sum;
	}
	int fracDigsProd()
	{
		int prod = 1;
		for (int i = 0; i < strlen(fracPart); i++)
		{
			prod *= fracPart[i] - 48;
			if (prod == 0)
				break;
		}
		return prod;
	}
	int fracMaxDig()
	{
		int dig = 0;
		for (int i = 0; i < strlen(fracPart); i++)
		{
			if (fracPart[i] - 48 > dig)
				dig = fracPart[i] - 48;
			if (dig == 9)
				break;
		}
		return dig;
	}
	int divCount()
	{
		int div = 2;
		for (int i = 2; i < wholePart / 2; i++)
		{
			if (wholePart % i == 0)
				div++;
		}
		return div;
	}
	int getFracDig(int pos)
	{
		return fracPart[pos] - 48;
	}
};

int *minFracDigsProd(DecNumber *arr, int count)
{
	int minProd = arr[0].fracDigsProd(), curProd, index[256], s = 0;
	index[0] = 0;
	index[1] = -1;
	for (int i = 1; i < count; i++)
	{
		curProd = arr[i].fracDigsProd();
		if (curProd < minProd)
		{
			minProd = curProd;
			index[0] = i;
			index[1] = -1;
			s = 0;
		}
		else if (curProd == minProd)
		{
			index[++s] = i;
			index[s + 1] = -1;
		}
	}
	cout << "There is(are) " << s + 1 << " number(s) with minimal product of its(their) digits in fractional part: ";
	for (int i = 0; i <= s; i++)
		cout << " " << arr[index[i]].wholePart << "." << arr[index[i]].fracPart;
	return index;
}

int *minFracHundrDig(DecNumber *arr, int count)
{
	int minDig = arr[0].getFracDig(1), curDig, index[256], s = 0;
	index[0] = 0;
	index[1] = -1;
	for (int i = 1; i < count; i++)
	{
		curDig = arr[i].getFracDig(1);
		if (curDig < minDig)
		{
			minDig = curDig;
			index[0] = i;
			index[1] = -1;
			s = 0;
		}
		else if (curDig == minDig)
		{
			index[++s] = i;
			index[s + 1] = -1;
		}
	}
	cout << "There is(are) " << s + 1 << " number(s) with smallest digit on 100th position in its(their) fractional part: ";
	for (int i = 0; i <= s; i++)
		cout << " " << arr[index[i]].wholePart << "." << arr[index[i]].fracPart;
	return index;
}

void quickSort(int *list, int left, int right, DecNumber *arr)
{
	int pivot = list[(left + right) / 2] , left_arrow = left, right_arrow = right;
	do
	{
		while (list[right_arrow] > pivot)
			right_arrow--;
		while (list[left_arrow] < pivot)
			left_arrow++;
		if (left_arrow <= right_arrow)
		{
			swap(list[left_arrow], list[right_arrow]);
			DecNumber t;
			memcpy(&t, &arr[left_arrow], sizeof(DecNumber));
			memcpy(&arr[left_arrow], &arr[right_arrow], sizeof(DecNumber));
			memcpy(&arr[right_arrow], &t, sizeof(DecNumber));
			left_arrow++; 
			right_arrow--;
		}
	} while (right_arrow >= left_arrow);
	if (left < right_arrow)
		quickSort(list, left, right_arrow, arr);
	if (left_arrow < right)
		quickSort(list, left_arrow, right, arr);
}
void sortByDividerCount(DecNumber *arr, int count)
{
	int list[256];
	for (int i = 0; i < count; i++)
		list[i] = arr[i].divCount();
	quickSort(list, 0, count-1, arr);
	cout << "\nSorted by dividers count: ";
	for (int i = 0; i < count; i++)
		cout << " " << arr[i].wholePart << "." << arr[i].fracPart;
}

void main()
{
	DecNumber *arr = new DecNumber[256];
	int  j = 0, l = 0, k = 0, b = 0;
	char buf[256], numbuf[256], commonArr[256][256];
	size_t g = 256;
	_cgets_s(buf, g, &g);
	for (int i = 0; i < strlen(buf); i++)
	{
		b = 0;
		while (buf[i] != ' ' && buf[i] != 0)
			numbuf[b++] = buf[i++];
		numbuf[b] = 0;
		if (b > 0)
		{
			arr[k] = DecNumber(numbuf);
			strcpy_s(commonArr[k++], numbuf);
		}
	}
	minFracHundrDig(arr, k);
	sortByDividerCount(arr, k);
	_getch();
}